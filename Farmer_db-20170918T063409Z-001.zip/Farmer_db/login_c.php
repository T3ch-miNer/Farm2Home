<?php

session_start();
$e_id=$_POST['e_id'];
$password=$_POST['pswd'];

$con=mysqli_connect("localhost","root","","customer_database");
$query="select * from f_details where e_id='$e_id' and pswd='$password'";
$result=mysqli_query($con,$query);

	if(mysqli_num_rows($result)>0)
	{
		header('Location: welcome.php');
	}
	else
	{
		header("Location: welcome.php");
		echo "Error in no. or password";
	}
	
	?>