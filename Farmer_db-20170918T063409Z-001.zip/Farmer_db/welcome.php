<?
    echo "welcome";

    echo "____this page should be displayed on logging in....";
?>

